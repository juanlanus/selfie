  // GE is the global object that holds "Edit Goals" data
  var GE = GE || {};

  GE.userGroups = [
    {
      groupName: "team",
      groupDescription: "G2G / StarMeUp",
      groupId:"StarMeUp" // includes users having "project":"StarMeUp",
    },
    {
      groupName: "others",
      groupDescription: "others",
      groupId:"*" // includes all users not previously listed (must be last)
    }
  ];

  GE.selectUsers = function( groupId, usersAlreadyListed ){
    console.log( 'select users for group ' + groupId );
    var thisGroup = [];
    _.each( 
      GE.users,
      function( thisUser, i, allUsers ){
        if( groupId === '*' ){
          if( ! usersAlreadyListed[ i ] ){
            thisGroup.push( thisUser);
          }
        } else {
          if( thisUser.project === groupId ){
            thisGroup.push( thisUser);
            usersAlreadyListed[ i ] = true;
          }
        }
      }
    );
    console.log( groupId + ' group: ' + thisGroup.length );
    return thisGroup;
  };

  // current user evaluations
  GE.evaluations = [];              // current user's evals in an array, [0] is last, current

  GE.nullEvaluation = {             // a null evaluation, just for structure
    userId:null,                    // id to associate with a user
    dateCreated:null,               // 
    dateLastModified:null,          // 
    locked:null,                    // true if the user can't modify it
    evalItems:[                     // the evaluation is an array of items of different types
      {
        id:null,                    // item id (internal)
        type:null,                  // item type: value, boolean, whatever...
        name:null,                  // item display name
        required:null,              // true if this item nust be always evaluated
        values: {                   // domain if item is enumarated
          1: {
            order:null,
            value:null,
            description:null
          },                        // continue with 2:{}, 3:{} ...
        },
        eval: {                     // assigned value
          value:null,               // the value itself (can be anything, depending on type)
          comment:null              // text entered by the evaluator
        }                           // 
      }
    ]                               // 
  };

  $(document).ready(function () {
    // _.each(list, iteratee, [context]) Alias: forEach 
    // Each invocation of iteratee is called with three arguments: (element, index, list).
    // If list is a JavaScript object, iteratee's arguments will be (value, key, list).

    // show users
    console.log( 'GE.users: ' + GE.users.length );  // JSON.stringify( GE.users, null, 2 ) );

    // build users list
    GE.usersAlreadyListed = []; // no users listed
    var templateSource = _.template( $( 'script#ge-template-users' ).html() ).source; // precompilation?
    var templateForUsers = _.template( $( 'script#ge-template-users' ).html() );
    var HTMLForUsers = templateForUsers( GE.userGroups );
    // leave HTML as is: $( '#ge-evalueeGroups' ).html( HTMLForUsers );
    // add empty padding at the bottom of the users list to ensure scroll to top
    $( '#ge-padding' ).height( window.height);


    // activate click-to-evaluate targets
    $( '#ge-evalueeGroups .ge-users-group' ).on(
      'click',
      function( event ){
        $this = $( event.target );
        // get a pointer to the individual user clicked on
        alert( 'must open evaluation context for this guy ' + ' id:' + $this.closest( 'li' )[0].id + ' ' );
        var $theItem = $this.closest( 'li' );
        var theUserId = $this.closest( 'li' )[0].id;

        // scroll the clicked LI to top of the viewport
        var itemOffset = $theItem.offset();
        $('html, body').animate({
          scrollTop: itemOffset.top,
          scrollLeft: itemOffset.left
        }); 

        // read any existing evaluations from localStorage, if none available create a random one

        // set a form for the current evaluation

        // on click on [save] store the current eval in localStorage
        
      }
    );
  });

