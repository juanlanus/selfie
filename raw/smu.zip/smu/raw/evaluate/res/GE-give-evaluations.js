  // GE is the global object that holds "Edit Goals" data
  var GE = GE || {};

  GE.evalItems = { // a mix of eval item definitions and individual values, must split
    1: { id:'1', type:'header', description:'First group of eval items', value:'' },
    2: { id:'2', type:'number', description:'Positive idiosyncrasy', value:'1527', topValue:'3000' },
    3: { id:'3', type:'p100', description:'Anthropometric synergic attitude', value:'42' },
    4: { id:'4', type:'binary', description:'Is a natural leadership junkie', value:true },
    5: { id:'5', type:'header', description:'group of eval items', value:'' },
    6: { id:'6', type:'binary', description:'Has that success tendancy', value:false },
    7: { id:'7', type:'step', description:'Advise acceptance', value:'high', index:3 },
    8: { id:'8', type:'spacer', description:'-', value:'' }
  };

  GE.userGroups = [
    {
      groupName: "team",
      groupDescription: "G2G / StarMeUp",
      groupId:"StarMeUp" // includes users having "project":"StarMeUp",
    },
    {
      groupName: "others",
      groupDescription: "others",
      groupId:"*" // includes all users not previously listed (must be last)
    }
  ];

  GE.selectUsers = function( groupId, usersAlreadyListed ){
    console.log( 'select users for group ' + groupId );
    var thisGroup = [];
    _.each( 
      GE.users,
      function( thisUser, i, allUsers ){
        if( groupId === '*' ){
          if( ! usersAlreadyListed[ i ] ){
            thisGroup.push( thisUser);
          }
        } else {
          if( thisUser.project === groupId ){
            thisGroup.push( thisUser);
            usersAlreadyListed[ i ] = true;
          }
        }
      }
    );
    console.log( groupId + ' group: ' + thisGroup.length );
    return thisGroup;
  };

  GE.getDisplayElement = function( $evalItem ){
  // given an element of an evaluation item, return a reference to its display
    return $evalItem.closest( '.ge-e-item' ).find( '.ge-e-display' ).text( ' ' );
  };

  GE.setDisplayText = function( $evalItem, displayText ){
  // given an element of an evaluation item, set its display text
    var $z = GE.getDisplayElement( $evalItem );
    $z.text( displayText );
  };

  GE.processKBInput = function( $e ){
    alert( 'handle KB input:' + $e.target.textContent.trim() );
  };

  GE.handleNumEvalClick = function( $this, $e, event, type, topValue ){
  // handle click on number and percent type items
    var isP100 = type === 'p100';
    if( isP100 ) { topValue = 100 };
    var $evalItem = $e.closest( '.ge-e-item' );
    var $A = $this.find( '.ge-value-A' );
    var $value = $this.find( '.ge-e-display' );
    var leftEdgePosition = $A.offset().left;
    if( $e.hasClass( 'ge-e-display' )){ // click on display area:
      // make display editable for a number value
      if( ! $e.attr( 'contenteditable' )) { return; }
      $e.attr( 'contenteditable' , true );
      // wait for input
      $e.one( 
        'blur',
        function( $this ){ GE.processKBInput( $this ); }
        // check input validity, display new value, compute valPx, display graphinc value
      );
    } else { // click on graphic display bar:
      // compute valPx proportional to value and resize bar
      var valPx = event.pageX - leftEdgePosition;
      $A.animate( { width: valPx } );
      // compute value and display it
      var value = '' + Math.round( valPx * topValue / $A.parent().width()) + ( isP100? '%' : '' );
      $value.text( value );
    }
  };

  GE.handleEvalClick = function( $e, event ){
    var $this = $e.closest( '.ge-e-item' );
    console.log( 'handling evaluation edit for ' + $this.attr( 'class' ) );
    var evalItemTypeClass = $this.attr('class').split(' ')[1]; // the 2nd class name
    var isKBInput = $e.hasClass( 'ge-e-display' ); // click was on display area
    switch( evalItemTypeClass ){
      case 'ge-e-header':
        return;
        break;
      case 'ge-e-number':
        var topValue = GE.evalItems[2].topValue;    // HARDCODED!!!
        GE.handleNumEvalClick( $this, $e, event, 'number', topValue );
        return;
        break;
      case 'ge-e-p100':
        GE.handleNumEvalClick( $this, $e, event, 'p100' );
        return;
        break;
      case 'ge-e-binary':
        var $z = $this.find( '.ge-e-binary-yes' );
        if( $z.length ){
          $z.removeClass( 'ge-e-binary-yes' ).addClass( 'ge-e-binary-no' );
          GE.setDisplayText( $z, '\u00A0' ); // &nbsp;
        } else {
          var $z = $this.find( '.ge-e-binary-no' );
          $z.removeClass( 'ge-e-binary-no' ).addClass( 'ge-e-binary-yes' );
          GE.setDisplayText( $z, '\u2713' ); // ✓
        }
        return;


      case 'ge-e-step':
      // handle click on enumerated type items
        var $evalItem = $e.closest( '.ge-e-item' );
        var $value = $this.find( '.ge-e-display' );

        if( $e.hasClass( 'ge-e-display' )){ // click on display area:
          // build and open a drop-down for the user to choose
        } else { // click on a value cell
          var value = event.target.textContent;
          $value.text( value );
          $evalItem.find( '.ge-e-one-step' ).removeClass( 'ge-e-one-step-on  ge-e-one-step-off' ).addClass( 'ge-e-one-step-on' );
          $( event.target ).nextAll().removeClass( 'ge-e-one-step-on' ).addClass( 'ge-e-one-step-off' );
        }
/*
  <div id="ge-e-item-7" class="ge-e-item ge-e-step">
    <div class="ge-e-value">
      <table>
        <tr>
          <td class="ge-e-one-step ge-e-one-step-on" style=" width:20%; ">awful</td>
          <td class="ge-e-one-step ge-e-one-step-on" style=" width:20%; ">low</td>
          <td class="ge-e-one-step ge-e-one-step-on" style=" width:20%; ">regular</td>
          <td class="ge-e-one-step ge-e-one-step-on" style=" width:20%; ">high</td>
          <td class="ge-e-one-step ge-e-one-step-off" style=" width:20%; ">impressing
          </td>
        </tr>
      </table>
    </div>
    <div class="ge-e-name">Advise acceptance</div>
    <div class="ge-e-display" contenteditable="false" tabindex="0">high</div>
  </div>
*/
        return;
        break;


      case 'ge-e-spacer':
        return;
        break;
      default:
        return;
        break;
    }
    
  };

  // current user evaluations
  GE.evaluations = [];              // current user's evals in an array, [0] is last, current

  GE.nullEvaluation = {             // a null evaluation, just for structure
    userId:null,                    // id to associate with a user
    dateCreated:null,               // 
    dateLastModified:null,          // 
    locked:null,                    // true if the user can't modify it
    evalItems:[                     // the evaluation is an array of items of different types
      {
        id:null,                    // item id (internal)
        type:null,                  // item type: value, boolean, whatever...
        name:null,                  // item display name
        required:null,              // true if this item nust be always evaluated
        values: {                   // domain if item is enumarated
          1: {
            order:null,
            value:null,
            description:null
          },                        // continue with 2:{}, 3:{} ...
        },
        eval: {                     // assigned value
          value:null,               // the value itself (can be anything, depending on type)
          comment:null              // text entered by the evaluator
        }                           // 
      }
    ]                               // 
  };

  $(document).ready(function () {
    // _.each(list, iteratee, [context]) Alias: forEach 
    // Each invocation of iteratee is called with three arguments: (element, index, list).
    // If list is a JavaScript object, iteratee's arguments will be (value, key, list).

    // show users
    console.log( 'GE.users: ' + GE.users.length );  // JSON.stringify( GE.users, null, 2 ) );

    // build users list
    GE.usersAlreadyListed = []; // no users listed
    var templateSource = _.template( $( 'script#ge-template-users' ).html() ).source; // precompilation?
    var templateForUsers = _.template( $( 'script#ge-template-users' ).html() );
    var HTMLForUsers = templateForUsers( GE.userGroups );
    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! $( '#ge-evalueeGroups' ).html( HTMLForUsers );
    // add empty padding at the bottom of the users list to ensure scroll to top
    $( '#ge-padding' ).height( window.height);


    // activate click event, for pretty much anything in this context
    $( '#ge-evalueeGroups .ge-users-group' ).on(
      'click',
      function( event ){
        $this = $( event.target );
        // get a pointer to the individual user clicked on
        // alert( 'must open evaluation context for this guy ' + ' id:' + $this.closest( 'li' )[0].id + ' ' );
        var $theItem = $this.closest( 'li' );
        var theUserId = $this.closest( 'li' )[0].id;
        var theEvalsId =  '#ge-evaluations-' + theUserId.split('-')[2]; // "5" of "ge-user-5"

        if( $this.closest( '.ge-user-data' ).length ){ // click on user header, scroll to top of viewport
          var itemOffset = $theItem.offset();
          $('html, body').animate({
            scrollTop: itemOffset.top,
            scrollLeft: itemOffset.left
          }); 
          return;
        };

        // handle when the evaluations input context is opened for this user
        var $e = $( theEvalsId );
        if( $e.css( 'display' ) === 'block' ){
          GE.handleEvalClick( $this, event );
          return;
        } // else close any other open evals context

        // read any existing evaluations from localStorage, if none available create a random one

        // set a form for the current evaluation

        // on click on [save] store the current eval in localStorage
        
      }
    );

    // activate click to edit an evaluation item value
    $( '#ge-evaluations-5 .ge-e-item' ).on(
      'click',
      function( event ){
        $this = $( event.delegateTarget );
        console.log( 'clicked: ' + $this.attr( 'class' ) + ' ' + $( event.target ).text().trim() );
      }
    );

  });

