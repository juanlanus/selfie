  $(function() {

    // create and display TOC
    $('#tocContainer').tocBuilder({ 
      type: 'headings', 
      backLinkText: 'TOC', 
      startLevel: 2, 
      endLevel: 6
    });

    // prevent TOC links from changing the location hash
    $('#tocContainer a, .tocBackLink').on(
      'click',
      function(e) {
        e.preventDefault();
        // console.log('TOC link clicked ' + e.currentTarget.hash);
        $('body, html').animate({
            'scrollTop': $(e.currentTarget.hash).offset().top - 33
        }, 500);
      }
    )

    // build minimenu inside <div class="miniMenu">
    var mmItems = [
      { text:'index', href:'index.html' },
      { text:'admin current', href:'smu-admin.html' },
      { text:'profiles', href:'smu-admin-new.html' },
      { text:'interaction', href:'smu-interaction.html' },
      { text:'data', href:'smu-data.html' },
      { text:'usability notes', href:'details.html' }
    ];
    var $mm = $( '<ul />' );
    for( var i = 0; i < mmItems.length; i++ ){
      console.log( mmItems[i].text + '\t' + mmItems[i].href  
      + '   ' + location.href );
      if( location.href.indexOf( mmItems[i].href ) > -1 ) { 
        // this page
        $mm.append( $( '<li class="currentPage">' + mmItems[i].text + '</li>' ) );
      } else {
        // different page
        $mm.append( $( '<li><a href="' + mmItems[i].href + '">' + mmItems[i].text + '</a></li>' ) );
      }
    };
    $( '.miniMenu' )
      .empty()
      .append( $mm );

});
