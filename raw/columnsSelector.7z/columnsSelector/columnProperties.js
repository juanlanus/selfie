var columnsData = {
    "RelationshipGroup": {
        "selected": true,
        "locked": true,
        "draggable": true,
        "resizable": true,
        "header": "Relationship Group",
        "title": "counterfeit description for Relationship Group to be replaced by something useful ",
        "name": "RelationshipGroup"
    },
    "AccountNumber": {
        "selected": true,
        "locked": true,
        "draggable": true,
        "resizable": true,
        "header": "Account Number",
        "title": "counterfeit description for Account Number to be replaced by something useful ",
        "name": "AccountNumber"
    },
    "AccountName": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Account Name",
        "title": "counterfeit description for Account Name to be replaced by something useful ",
        "name": "AccountName"
    },
    "StatusCategory": {
        "resizable": true,
        "header": "Status Category",
        "title": "counterfeit description for Status Category to be replaced by something useful ",
        "name": "StatusCategory"
    },
    "ADP": {
        "resizable": true,
        "header": "ADP",
        "title": "counterfeit description for ADP to be replaced by something useful ",
        "name": "ADP"
    },
    "ISIN": {
        "resizable": true,
        "header": "ISIN",
        "title": "counterfeit description for ISIN to be replaced by something useful ",
        "name": "ISIN"
    },
    "PrimaryInstrument": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Primary Instrument",
        "title": "counterfeit description for Primary Instrument to be replaced by something useful ",
        "name": "PrimaryInstrument"
    },
    "Side": {
        "resizable": true,
        "header": "Side",
        "title": "counterfeit description for Side to be replaced by something useful ",
        "name": "Side"
    },
    "PrimaryQuantity": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Primary Quantity",
        "title": "counterfeit description for Primary Quantity to be replaced by something useful ",
        "name": "PrimaryQuantity"
    },
    "OpenQuantity": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Open Quantity",
        "title": "counterfeit description for Open Quantity to be replaced by something useful ",
        "name": "OpenQuantity"
    },
    "Price": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Price",
        "title": "counterfeit description for Price to be replaced by something useful ",
        "name": "Price"
    },
    "NetConsideration": {
        "resizable": true,
        "header": "Net Consideration",
        "title": "counterfeit description for Net Consideration to be replaced by something useful ",
        "name": "NetConsideration"
    },
    "OpenConsideration": {
        "resizable": true,
        "header": "Open Consideration",
        "title": "counterfeit description for Open Consideration to be replaced by something useful ",
        "name": "OpenConsideration"
    },
    "OpenConsideration-USDEquiv": {
        "resizable": true,
        "header": "Open Consideration-USD Equiv",
        "title": "counterfeit description for Open Consideration-USD Equiv to be replaced by something useful ",
        "name": "OpenConsideration-USDEquiv"
    },
    "SettleCurrency": {
        "resizable": true,
        "header": "Settle Currency",
        "title": "counterfeit description for Settle Currency to be replaced by something useful ",
        "name": "SettleCurrency"
    },
    "ExchangeRate": {
        "resizable": true,
        "header": "Exchange Rate",
        "title": "counterfeit description for Exchange Rate to be replaced by something useful ",
        "name": "ExchangeRate"
    },
    "TradeDate": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Trade Date",
        "title": "counterfeit description for Trade Date to be replaced by something useful ",
        "name": "TradeDate"
    },
    "ValueDate": {
        "resizable": true,
        "header": "Value Date",
        "title": "counterfeit description for Value Date to be replaced by something useful ",
        "name": "ValueDate"
    },
    "CounterpartyReference": {
        "resizable": true,
        "header": "Counterparty Reference",
        "title": "counterfeit description for Counterparty Reference to be replaced by something useful ",
        "name": "CounterpartyReference"
    },
    "CounterpartyDescription": {
        "resizable": true,
        "header": "Counterparty Description",
        "title": "counterfeit description for Counterparty Description to be replaced by something useful ",
        "name": "CounterpartyDescription"
    },
    "TradeReference": {
        "resizable": true,
        "header": "Trade Reference",
        "title": "counterfeit description for Trade Reference to be replaced by something useful ",
        "name": "TradeReference"
    },
    "Age": {
        "resizable": true,
        "header": "Age",
        "title": "counterfeit description for Age to be replaced by something useful ",
        "name": "Age"
    },
    "Agedays": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Agedays",
        "title": "counterfeit description for Agedays to be replaced by something useful ",
        "name": "Agedays"
    },
    "Market": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Market",
        "title": "counterfeit description for Market to be replaced by something useful ",
        "name": "Market"
    },
    "Buy-inMarket": {
        "resizable": true,
        "header": "Buy-in Market",
        "title": "counterfeit description for Buy-in Market to be replaced by something useful ",
        "name": "Buy-inMarket"
    },
    "IDMarket": {
        "resizable": true,
        "header": "IDMarket",
        "title": "counterfeit description for IDMarket to be replaced by something useful ",
        "name": "IDMarket"
    },
    "AutoFX": {
        "resizable": true,
        "header": "Auto FX",
        "title": "counterfeit description for Auto FX to be replaced by something useful ",
        "name": "AutoFX"
    },
    "HighValue/Qty": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "High Value/Qty",
        "title": "counterfeit description for High Value/Qty to be replaced by something useful ",
        "name": "HighValue/Qty"
    },
    "MiddleOfficeKeyClient": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Middle Office Key Client",
        "title": "counterfeit description for Middle Office Key Client to be replaced by something useful ",
        "name": "MiddleOfficeKeyClient"
    },
    "BankStatusNarrative": {
        "resizable": true,
        "header": "Bank Status Narrative",
        "title": "counterfeit description for Bank Status Narrative to be replaced by something useful ",
        "name": "BankStatusNarrative"
    },
    "BankStatusDescription": {
        "resizable": true,
        "header": "Bank Status Description",
        "title": "counterfeit description for Bank Status Description to be replaced by something useful ",
        "name": "BankStatusDescription"
    },
    "InternalComments": {
        "resizable": true,
        "header": "Internal Comments",
        "title": "counterfeit description for Internal Comments to be replaced by something useful ",
        "name": "InternalComments"
    },
    "UpdatePending": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Update Pending",
        "title": "counterfeit description for Update Pending to be replaced by something useful ",
        "name": "UpdatePending"
    },
    "NAClientService": {
        "resizable": true,
        "header": "NAClient Service",
        "title": "counterfeit description for NAClient Service to be replaced by something useful ",
        "name": "NAClientService"
    },
    "EMEAClientService": {
        "resizable": true,
        "header": "EMEA Client Service",
        "title": "counterfeit description for EMEA Client Service to be replaced by something useful ",
        "name": "EMEAClientService"
    },
    "APACClientService": {
        "resizable": true,
        "header": "APAC Client Service",
        "title": "counterfeit description for APAC Client Service to be replaced by something useful ",
        "name": "APACClientService"
    },
    "NAMOClientFacing": {
        "resizable": true,
        "header": "NAMO: Client Facing",
        "title": "counterfeit description for NAMO: Client Facing to be replaced by something useful ",
        "name": "NAMO: ClientFacing"
    },
    "EMEAMOClientFacing": {
        "resizable": true,
        "header": "EMEAMO: Client Facing",
        "title": "counterfeit description for EMEAMO: Client Facing to be replaced by something useful ",
        "name": "EMEAMO: ClientFacing"
    },
    "APACMOClientFacing": {
        "resizable": true,
        "header": "APACMO: Client Facing",
        "title": "counterfeit description for APACMO: Client Facing to be replaced by something useful ",
        "name": "APACMO: ClientFacing"
    },
    "Business": {
        "resizable": true,
        "header": "Business",
        "title": "counterfeit description for Business to be replaced by something useful ",
        "name": "Business"
    },
    "BankStatus": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Bank Status",
        "title": "counterfeit description for Bank Status to be replaced by something useful ",
        "name": "BankStatus"
    },
    "AssignedTo": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Assigned To",
        "title": "counterfeit description for Assigned To to be replaced by something useful ",
        "name": "AssignedTo"
    },
    "OperationType": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Operation Type",
        "title": "counterfeit description for Operation Type to be replaced by something useful ",
        "name": "OperationType"
    },
    "RELMID": {
        "resizable": true,
        "header": "RELMID",
        "title": "counterfeit description for RELMID to be replaced by something useful ",
        "name": "RELMID"
    },
    "RELMName": {
        "resizable": true,
        "header": "RELMName",
        "title": "counterfeit description for RELMName to be replaced by something useful ",
        "name": "RELMName"
    },
    "FamilyCode": {
        "resizable": true,
        "header": "Family Code",
        "title": "counterfeit description for Family Code to be replaced by something useful ",
        "name": "FamilyCode"
    },
    "FamilyName": {
        "resizable": true,
        "header": "Family Name",
        "title": "counterfeit description for Family Name to be replaced by something useful ",
        "name": "FamilyName"
    },
    "RelationshipID": {
        "resizable": true,
        "header": "Relationship ID",
        "title": "counterfeit description for Relationship ID to be replaced by something useful ",
        "name": "RelationshipID"
    },
    "ClearanceCode": {
        "resizable": true,
        "header": "Clearance Code",
        "title": "counterfeit description for Clearance Code to be replaced by something useful ",
        "name": "ClearanceCode"
    },
    "RAG": {
        "resizable": true,
        "header": "RAG",
        "title": "counterfeit description for RAG to be replaced by something useful ",
        "name": "RAG"
    },
    "ExceptionTrades": {
        "resizable": true,
        "header": "Exception Trades",
        "title": "counterfeit description for Exception Trades to be replaced by something useful ",
        "name": "ExceptionTrades"
    },
    "NAMOClientFacingTeamLead": {
        "resizable": true,
        "header": "NAMO: Client Facing Team Lead",
        "title": "counterfeit description for NAMO: Client Facing Team Lead to be replaced by something useful ",
        "name": "NAMO: ClientFacingTeamLead"
    },
    "EMEAMOClientFacingTeamLead": {
        "resizable": true,
        "header": "EMEAMO: Client Facing Team Lead",
        "title": "counterfeit description for EMEAMO: Client Facing Team Lead to be replaced by something useful ",
        "name": "EMEAMO: ClientFacingTeamLead"
    },
    "APACMOClientFacingTeamLead": {
        "resizable": true,
        "header": "APACMO: Client Facing Team Lead",
        "title": "counterfeit description for APACMO: Client Facing Team Lead to be replaced by something useful ",
        "name": "APACMO: ClientFacingTeamLead"
    },
    "Region": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Region",
        "title": "counterfeit description for Region to be replaced by something useful ",
        "name": "Region"
    },
    "BrokerCoverage": {
        "resizable": true,
        "header": "Broker Coverage",
        "title": "counterfeit description for Broker Coverage to be replaced by something useful ",
        "name": "BrokerCoverage"
    },
    "MOPrematchingCoverage": {
        "resizable": true,
        "header": "MO: Prematching Coverage",
        "title": "counterfeit description for MO: Prematching Coverage to be replaced by something useful ",
        "name": "MO: PrematchingCoverage"
    },
    "NAClientServiceTeamLead": {
        "resizable": true,
        "header": "NAClient Service Team Lead",
        "title": "counterfeit description for NAClient Service Team Lead to be replaced by something useful ",
        "name": "NAClientServiceTeamLead"
    },
    "EMEAClientServiceTeamLead": {
        "resizable": true,
        "header": "EMEA Client Service Team Lead",
        "title": "counterfeit description for EMEA Client Service Team Lead to be replaced by something useful ",
        "name": "EMEAClientServiceTeamLead"
    },
    "APACClientServiceTeamLead": {
        "resizable": true,
        "header": "APAC Client Service Team Lead",
        "title": "counterfeit description for APAC Client Service Team Lead to be replaced by something useful ",
        "name": "APACClientServiceTeamLead"
    },
    "Exposure": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Exposure",
        "title": "counterfeit description for Exposure to be replaced by something useful ",
        "name": "Exposure"
    },
    "TradeStatus": {
        "resizable": true,
        "header": "Trade Status",
        "title": "counterfeit description for Trade Status to be replaced by something useful ",
        "name": "TradeStatus"
    },
    "CompanyGlossReference": {
        "resizable": true,
        "header": "Company Gloss Reference",
        "title": "counterfeit description for Company Gloss Reference to be replaced by something useful ",
        "name": "CompanyGlossReference"
    },
    "LegalEntity": {
        "selected": true,
        "draggable": true,
        "resizable": true,
        "header": "Legal Entity",
        "title": "counterfeit description for Legal Entity to be replaced by something useful ",
        "name": "LegalEntity"
    },
    "AssetServicingEvent": {
        "resizable": true,
        "header": "Asset Servicing Event",
        "title": "counterfeit description for Asset Servicing Event to be replaced by something useful ",
        "name": "AssetServicingEvent"
    },
    "ASEventDeadlineDate": {
        "resizable": true,
        "header": "ASEvent Deadline Date",
        "title": "counterfeit description for ASEvent Deadline Date to be replaced by something useful ",
        "name": "ASEventDeadlineDate"
    },
    "SettlementTypeDescription": {
        "resizable": true,
        "header": "Settlement Type Description",
        "title": "counterfeit description for Settlement Type Description to be replaced by something useful ",
        "name": "SettlementTypeDescription"
    },
    "Origin": {
        "resizable": true,
        "header": "Origin",
        "title": "counterfeit description for Origin to be replaced by something useful ",
        "name": "Origin"
    },
    "RrNo": {
        "resizable": true,
        "header": "Rr No",
        "title": "counterfeit description for Rr No to be replaced by something useful ",
        "name": "RrNo"
    },
    "CpartyExternalReference": {
        "resizable": true,
        "header": "Cparty External Reference",
        "title": "counterfeit description for Cparty External Reference to be replaced by something useful ",
        "name": "CpartyExternalReference"
    },
    "Postage": {
        "resizable": true,
        "header": "Postage",
        "title": "counterfeit description for Postage to be replaced by something useful ",
        "name": "Postage"
    },
    "Stamp": {
        "resizable": true,
        "header": "Stamp",
        "title": "counterfeit description for Stamp to be replaced by something useful ",
        "name": "Stamp"
    },
    "Tariff": {
        "resizable": true,
        "header": "Tariff",
        "title": "counterfeit description for Tariff to be replaced by something useful ",
        "name": "Tariff"
    },
    "Vat": {
        "resizable": true,
        "header": "Vat",
        "title": "counterfeit description for Vat to be replaced by something useful ",
        "name": "Vat"
    },
    "Levy": {
        "resizable": true,
        "header": "Levy",
        "title": "counterfeit description for Levy to be replaced by something useful ",
        "name": "Levy"
    },
    "AccruedInterest": {
        "resizable": true,
        "header": "Accrued Interest",
        "title": "counterfeit description for Accrued Interest to be replaced by something useful ",
        "name": "AccruedInterest"
    },
    "Commission": {
        "resizable": true,
        "header": "Commission",
        "title": "counterfeit description for Commission to be replaced by something useful ",
        "name": "Commission"
    },
    "ActualSettleDate": {
        "resizable": true,
        "header": "Actual Settle Date",
        "title": "counterfeit description for Actual Settle Date to be replaced by something useful ",
        "name": "ActualSettleDate"
    },
    "GrossCredit": {
        "resizable": true,
        "header": "Gross Credit",
        "title": "counterfeit description for Gross Credit to be replaced by something useful ",
        "name": "GrossCredit"
    },
    "TradeVersion": {
        "resizable": true,
        "header": "Trade Version",
        "title": "counterfeit description for Trade Version to be replaced by something useful ",
        "name": "TradeVersion"
    },
    "TradingCurrency": {
        "resizable": true,
        "header": "Trading Currency",
        "title": "counterfeit description for Trading Currency to be replaced by something useful ",
        "name": "TradingCurrency"
    },
    "SettleQuantity": {
        "resizable": true,
        "header": "Settle Quantity",
        "title": "counterfeit description for Settle Quantity to be replaced by something useful ",
        "name": "SettleQuantity"
    },
    "TradeType": {
        "resizable": true,
        "header": "Trade Type",
        "title": "counterfeit description for Trade Type to be replaced by something useful ",
        "name": "TradeType"
    },
    "OperationTypeDescription": {
        "resizable": true,
        "header": "Operation Type Description",
        "title": "counterfeit description for Operation Type Description to be replaced by something useful ",
        "name": "OperationTypeDescription"
    },
    "PrincipalTradeCurrency": {
        "resizable": true,
        "header": "Principal Trade Currency",
        "title": "counterfeit description for Principal Trade Currency to be replaced by something useful ",
        "name": "PrincipalTradeCurrency"
    },
    "PrincipalSettlingCurrency": {
        "resizable": true,
        "header": "Principal Settling Currency",
        "title": "counterfeit description for Principal Settling Currency to be replaced by something useful ",
        "name": "PrincipalSettlingCurrency"
    },
    "FinanceRate": {
        "resizable": true,
        "header": "Finance Rate",
        "title": "counterfeit description for Finance Rate to be replaced by something useful ",
        "name": "FinanceRate"
    },
    "TRSTradeRef": {
        "resizable": true,
        "header": "TRSTrade Ref",
        "title": "counterfeit description for TRSTrade Ref to be replaced by something useful ",
        "name": "TRSTradeRef"
    },
    "TGID": {
        "resizable": true,
        "header": "TGID",
        "title": "counterfeit description for TGID to be replaced by something useful ",
        "name": "TGID"
    },
    "SEMEID": {
        "resizable": true,
        "header": "SEMEID",
        "title": "counterfeit description for SEMEID to be replaced by something useful ",
        "name": "SEMEID"
    },
    "LinkType": {
        "resizable": true,
        "header": "Link Type",
        "title": "counterfeit description for Link Type to be replaced by something useful ",
        "name": "LinkType"
    },
    "UserName": {
        "resizable": true,
        "header": "User Name",
        "title": "counterfeit description for User Name to be replaced by something useful ",
        "name": "UserName"
    },
    "ExchangeRateIndicator": {
        "resizable": true,
        "header": "Exchange Rate Indicator",
        "title": "counterfeit description for Exchange Rate Indicator to be replaced by something useful ",
        "name": "ExchangeRateIndicator"
    },
    "SettlementDiv": {
        "resizable": true,
        "header": "Settlement Div",
        "title": "counterfeit description for Settlement Div to be replaced by something useful ",
        "name": "SettlementDiv"
    },
    "SpecialInstr1": {
        "resizable": true,
        "header": "Special Instr1",
        "title": "counterfeit description for Special Instr1 to be replaced by something useful ",
        "name": "SpecialInstr1"
    },
    "SpecialInstr2": {
        "resizable": true,
        "header": "Special Instr2",
        "title": "counterfeit description for Special Instr2 to be replaced by something useful ",
        "name": "SpecialInstr2"
    },
    "SpecialInstr3": {
        "resizable": true,
        "header": "Special Instr3",
        "title": "counterfeit description for Special Instr3 to be replaced by something useful ",
        "name": "SpecialInstr3"
    },
    "SpecialInstr4": {
        "resizable": true,
        "header": "Special Instr4",
        "title": "counterfeit description for Special Instr4 to be replaced by something useful ",
        "name": "SpecialInstr4"
    },
    "TimeStamp": {
        "resizable": true,
        "header": "Time Stamp",
        "title": "counterfeit description for Time Stamp to be replaced by something useful ",
        "name": "TimeStamp"
    },
    "TradeNo": {
        "resizable": true,
        "header": "Trade No",
        "title": "counterfeit description for Trade No to be replaced by something useful ",
        "name": "TradeNo"
    },
    "InstNumber": {
        "resizable": true,
        "title": "counterfeit description for Inst Number",
        "name": "InstNumber"
    },
    "Service": {
        "resizable": true,
        "header": "Service",
        "title": "counterfeit description for Service to be replaced by something useful ",
        "name": "Service"
    },
    "Status": {
        "resizable": true,
        "header": "Status",
        "title": "counterfeit description for Status to be replaced by something useful ",
        "name": "Status"
    },
    "TradeTypeDescription": {
        "resizable": true,
        "header": "Trade Type Description",
        "title": "counterfeit description for Trade Type Description to be replaced by something useful ",
        "name": "TradeTypeDescription"
    },
    "AgeCategory": {
        "resizable": true,
        "header": "Age Category",
        "title": "counterfeit description for Age Category to be replaced by something useful ",
        "name": "AgeCategory"
    }
};
