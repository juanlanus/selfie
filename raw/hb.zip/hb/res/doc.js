/************ GENERAL PURPOSE FUNCTIONS, FOR ALL PAGES ****************/

  $(function() {

    // display file timestamp
    displayFileTimestamp = function() {

      // add one leading zero
      function addLeadingZero( n ){
        if( n < 10 ){
          return '0' + n;
        } else {
          return '' + n;
        }
      };

      // display file timestamp
      // TODO: check if server is sending the date in the response headers, if it's not
      // then use the date stored by Amaya, if not available then show nothing
      var now = new Date();
      var t = new Date(Date.parse(document.lastModified));
      var tx = '' 
      tx += t.getFullYear() + '-' 
      tx += addLeadingZero( (t.getMonth() + 1) ) + '-' 
      tx += addLeadingZero( t.getDate() ) + ' ' 
      tx += t.getHours() - 3 + ':' 
      tx += addLeadingZero( t.getMinutes() );
      // don't overwrite Amaya's save date
      $('#fileTimestamp').text(tx);
    };

    // create and display TOC
    $('#docHeader').find( 'ul' ).css( 'display', 'none' );
    $('#tocContainer').tocBuilder({ 
      type: 'headings', 
      backLinkText: 'TOC', 
      startLevel: 2, 
      endLevel: 6
    });

    // prevent TOC links from changing the location hash
    // TODO: anyway, should add the position changes to history
    $('#tocContainer a, .tocBackLink').on(
      'click',
      function(e) {
        e.preventDefault();
        // console.log('TOC link clicked ' + e.currentTarget.hash);
        $('body, html').animate({
            'scrollTop': $(e.currentTarget.hash).offset().top - 33
        }, 500);
      }
    );

    // on scroll, make the top fixed heading dissapear
    $( window ).scroll(
      function(){
        // $( '.fixedHeader' ).css( 'opacity', '0.1' );
        if ($(this).scrollTop() > 60 ) {
          $('.fixedHeader').slideUp( 555 );
        } else {
          $('.fixedHeader').slideDown( 222 );
        }
      }
    );

    // build minimenu inside <div class="miniMenu">
    var mmItems = [
      { href:'index.html', text:'index' },
      { href:'concept.html', text:'concept' },
      { href:'useCases.html', text:'use cases' },
      { href:'notificacionEmail.html', text:'notificacion email' },
      { href:'architecture.html', text:'architecture' },
      { href:'glossary.html', text:'glossary' }
    ];
    var $mm = $( '<ul />' );
    for( var i = 0; i < mmItems.length; i++ ){
      // console.log( mmItems[i].text + '\t' + mmItems[i].href );
      $mm.append( $( '<li><a href="' + mmItems[i].href + '">' + mmItems[i].text + '</a></li>' ) );
    };
    $( '.miniMenu' )
      .empty()
      .append( $mm );

  });

