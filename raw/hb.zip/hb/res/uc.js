  $(function() {


    /*************************** USE CASES ********************************/
    // activate extensions toggler
    // The use-case extensions toggler:a button that hides/displays extensions
    // The extensions are the ol's in the main success scenario with type="a"
    if( $('.uc-mainSuccessScenario ol[type="a"]').length ){

      // create button
      $( '<div id="uc-extensionsToggler" />' )
      .append( '<button type="button">toggle<br>extensions</button>' )
      .insertAfter( $( '#uc-mainSuccessScenario > h5' ) );

      // bind action to button
      $('#uc-extensionsToggler button').on(
        'click', 
        function(event) {
          $('.uc-mainSuccessScenario ol[type="a"]').toggle(200);
        } 
      );
    };

    // show extension in a different color
    $('.uc- ol[type="a"]').css('color', 'rgb(80,80,80)'); 

    // display selected UC items
    var uc_itemsVisibility = [
      { itemId:'uc-brief', visible:true },
      { itemId:'uc-preconditions', visible:false },
      { itemId:'uc-primaryActor', visible:true },
      { itemId:'uc-level', visible:false },
      { itemId:'uc-trigger', visible:false },
      { itemId:'uc-successEnd', visible:false },
      { itemId:'uc-failedEnd', visible:false },
      { itemId:'uc-mainSuccessScenario', visible:true }
    ];
    for( var i = 0; i < uc_itemsVisibility.length; i++ ){
      var oneItem = uc_itemsVisibility[i];
      var $uc_element = $( '#' + oneItem.itemId );
      if( $uc_element.length ){
         $uc_element.css( 'display', oneItem.visible ? 'block' : 'none' );
      }
    };

    // set initial extensions visibility
    var uc_extensionsVisibility = false;
    $('.uc-mainSuccessScenario ol[type="a"]')
    .css( 'display', uc_extensionsVisibility ? 'block' : 'none' );

  });
